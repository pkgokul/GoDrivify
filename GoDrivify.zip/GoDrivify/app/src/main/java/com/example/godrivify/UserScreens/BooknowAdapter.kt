package com.example.godrivify.UserScreens

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.AppCompatImageButton
import androidx.core.net.toFile
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.godrivify.R
import com.example.godrivify.api.ApiService
import com.example.godrivify.api.RetrofitClient
import com.example.godrivify.model.BookingShowDriver
import com.example.godrivify.response.Fetch
import de.hdodenhof.circleimageview.CircleImageView
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class BooknowAdapter(
    private val itemList: ArrayList<Fetch>, private val context: Context
) : RecyclerView.Adapter<BooknowAdapter.ItemViewHolder>() {

    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val driverName: TextView = itemView.findViewById(R.id.driverName)
        val profileImage: ImageView = itemView.findViewById(R.id.profileui)
        val bookNowButton: Button = itemView.findViewById(R.id.bookBtn)
        val date: TextView = itemView.findViewById(R.id.date)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.booknow_layout, parent, false)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = itemList[position]

        // Set driver details
        holder.driverName.text = item.name
        holder.date.text = item.availability_date

        // Load profile image using Glide
        Glide.with(context)
            .load(item.image_path)
            .placeholder(R.drawable.baseline_person_24)
            .into(holder.profileImage)

        // Handle item click to show driver profile
        holder.itemView.setOnClickListener {
            showDriverProfileDialog(item)
        }

        // Handle book now button click
        holder.bookNowButton.setOnClickListener {
            showBookingDialog(item)
        }
    }

    override fun getItemCount(): Int = itemList.size

    // Function to display driver profile
    private fun showDriverProfileDialog(item: Fetch) {
        val builder = AlertDialog.Builder(context)
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.driver_profile_view, null)

        val imageUser: CircleImageView = view.findViewById(R.id.image_user)
        val textName: TextView = view.findViewById(R.id.text_name)
        val textRole: TextView = view.findViewById(R.id.text_role)
        val textEmail: TextView = view.findViewById(R.id.text_email)
        val textContact: TextView = view.findViewById(R.id.text_contact)
        val language: TextView = view.findViewById(R.id.text_language)
        val age: TextView = view.findViewById(R.id.text_age)
        val experience: TextView = view.findViewById(R.id.text_experience)
        val lic: ImageView = view.findViewById(R.id.image_license)

        // Load profile image
        Glide.with(context)
            .load(item.image_path)
            .placeholder(R.drawable.baseline_person_24)
            .into(imageUser)

        Glide.with(context)
            .load(item.lic_image)
            .placeholder(R.drawable.baseline_person_24)
            .into(lic)

        // Set text values
        textName.text = item.name
        textRole.text = item.role ?: "N/A"
        textEmail.text = item.email ?: "N/A"
        textContact.text = item.contact_number ?: "N/A"
        language.text = item.language
        age.text = item.age.toString()
        experience.text = item.experienceyears.toString()

        builder.setView(view)
        builder.setPositiveButton("Close") { dialog, _ -> dialog.dismiss() }

        val dialog = builder.create()
        dialog.show()
    }


    @SuppressLint("MissingInflatedId")
    private fun showBookingDialog(item: Fetch) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Booking Details")

        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.dialog, null)

        val pickupEditText = view.findViewById<EditText>(R.id.etPickup)
        val dropEditText = view.findViewById<EditText>(R.id.etDrop)
        val selectedImageView = view.findViewById<ImageView>(R.id.carImage) // Add this in dialog.xml

        var selectedImageUri: Uri? = null

        selectedImageView.setOnClickListener {
            (context as? Activity)?.let { activity ->
                val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                activity.startActivityForResult(intent, IMAGE_PICK_CODE)
            }
        }

        builder.setView(view)
        builder.setPositiveButton("Confirm") { _, _ ->
            val pickup = pickupEditText.text.toString().trim()
            val drop = dropEditText.text.toString().trim()

            if (pickup.isNotEmpty() && drop.isNotEmpty() && selectedImageUri != null) {
                sendBookingDetails(item, pickup, drop, selectedImageUri!!)
            } else {
                Toast.makeText(context, "Please fill all fields and select an image", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()

        // Function to update image view after selection
        fun updateSelectedImage(uri: Uri) {
            selectedImageUri = uri
            Glide.with(context)
                .load(uri)
                .placeholder(R.drawable.baseline_person_24)
                .into(selectedImageView)
        }

        // Save the callback function in the activity
        (context as? Booknow)?.setImageCallback { uri ->
            updateSelectedImage(uri)
        }
    }


    // Handle the result of image selection in Activity
    companion object {
        const val IMAGE_PICK_CODE = 1000
    }


    // Function to send booking details to the server using Retrofit
    private fun sendBookingDetails(item: Fetch, pickup: String, drop: String, imageUri: Uri) {
        val apiService = RetrofitClient.instance.create(ApiService::class.java)

        val userid = RequestBody.create("text/plain".toMediaTypeOrNull(),"31")
        val driverId = RequestBody.create("text/plain".toMediaTypeOrNull(), item.id.toString())
        val dateOfBooking = RequestBody.create("text/plain".toMediaTypeOrNull(), "2025-03-21")
        val status = RequestBody.create("text/plain".toMediaTypeOrNull(), "Pending")
        val pickupLocation = RequestBody.create("text/plain".toMediaTypeOrNull(), pickup)
        val dropLocation = RequestBody.create("text/plain".toMediaTypeOrNull(), drop)
        val carName = RequestBody.create("text/plain".toMediaTypeOrNull(), "Toyota Camry")

        // Convert URI to File for Android 10+
        val contentResolver = context.contentResolver
        val inputStream = contentResolver.openInputStream(imageUri)
        val tempFile = File.createTempFile("upload_", ".jpg", context.cacheDir)
        tempFile.outputStream().use { outputStream -> inputStream?.copyTo(outputStream) }

        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), tempFile)
        val carImagePart = MultipartBody.Part.createFormData("car_image", tempFile.name, requestFile)

        val call = apiService.insertBooking(userid, driverId, dateOfBooking, status, pickupLocation, dropLocation, carName, carImagePart)

        call?.enqueue(object : Callback<BookingShowDriver?> {
            override fun onResponse(call: Call<BookingShowDriver?>, response: Response<BookingShowDriver?>) {
                if (response.isSuccessful && response.body()?.status == "success") {
                    Toast.makeText(context, "Booking Successful!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Booking Failed!", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<BookingShowDriver?>, t: Throwable) {
                Log.e("Booking Error", t.message ?: "Unknown Error")
                Toast.makeText(context, "Network Error!", Toast.LENGTH_SHORT).show()
            }
        })
    }



}

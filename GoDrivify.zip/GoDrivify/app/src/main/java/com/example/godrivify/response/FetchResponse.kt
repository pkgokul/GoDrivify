package com.example.godrivify.response

data class FetchResponse(
    val status: String,
    val data: List<Fetch>
)

data class Fetch(
    val id: String,
    val userid: String,
    val availability: String,
    val availability_date: String,
    val name: String,
    val username: String,
    val email: String,
    val role: String,
    val password: String,
    val contact_number: String,
    val image_path: String,
    val age: Int,
    val experienceyears: Int,
    val profile_image: String?,
    val lic_image: String?,
    val language: String
)

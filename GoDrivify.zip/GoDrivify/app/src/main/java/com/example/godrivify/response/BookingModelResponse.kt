package com.example.godrivify.response

data class DriverBookingListModel(
    val id: Int,
    val userid: Int,
    val username: String,  // This field is now correctly mapped from PHP
    val dateofbooking: String,
    val status: String
)

data class DriverBookingListResponse(
    val status: Boolean,
    val message: String,
    val data: List<DriverBookingListModel> = emptyList() // Default empty list to avoid null issues
)

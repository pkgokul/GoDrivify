package com.example.godrivify.response

data class DriverInfoResponse(
    val status: Boolean,
    val message: String,
    val userid: String
)

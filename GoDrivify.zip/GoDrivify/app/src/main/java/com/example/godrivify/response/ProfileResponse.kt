package com.example.godrivify.response

data class ProfileResponse(
    val status: Boolean,
    val message: String,
    val data: UserProfile
)

data class UserProfile(
    val name: String,
    val username: String,
    val contact_number: String, // Ensure this matches the API response key
    val email: String,
    val password: String,
    val image_path: String
)

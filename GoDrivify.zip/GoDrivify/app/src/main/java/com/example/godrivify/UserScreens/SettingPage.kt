package com.example.godrivify.UserScreens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.example.godrivify.AboutUsActivity
import com.example.godrivify.DeleteAccountActivity
import com.example.godrivify.PrivacyPolicyActivity  // Import PrivacyPolicyActivity
import com.example.godrivify.R

class SettingPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings)

        val btnBack: ImageButton = findViewById(R.id.btn_back)
        val btnAboutUs: Button = findViewById(R.id.btn_about_us)
        val btnPrivacyPolicy: Button = findViewById(R.id.btn_privacy_policy)
        val btnDeleteAccount: Button = findViewById(R.id.btn_delete_account)

        // Navigate back
        btnBack.setOnClickListener {
            finish()
        }

        // Navigate to About Us page
        btnAboutUs.setOnClickListener {
            val intent = Intent(this@SettingPage, AboutUsActivity::class.java)
            startActivity(intent)
        }

        // Navigate to Privacy Policy page
        btnPrivacyPolicy.setOnClickListener {
            val intent = Intent(this@SettingPage, PrivacyPolicyActivity::class.java)
            startActivity(intent)
        }

        // Navigate to Delete Account page
        btnDeleteAccount.setOnClickListener {
            val intent = Intent(this@SettingPage, DeleteAccountActivity::class.java)
            startActivity(intent)
        }
    }
}

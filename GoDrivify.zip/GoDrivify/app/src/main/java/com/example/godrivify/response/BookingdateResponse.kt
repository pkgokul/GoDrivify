data class BookingdateResponse(
    val status: String,
    val message: String
)

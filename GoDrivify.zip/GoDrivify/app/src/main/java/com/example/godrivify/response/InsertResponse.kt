package com.example.godrivify.response

data class InsertResponse(
    val status: Boolean,
    val message: String,
    val image_url: String
)

package com.example.godrivify.UserScreens

class UserDriverStatusModel(
    val imageRes:Int,
    val name:String
)
package com.example.godrivify.UserScreens


import android.os.Bundle
import android.util.Log
import android.widget.RatingBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.godrivify.R
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONObject

class ReviewActivity : AppCompatActivity() {
    private lateinit var ratingBar: RatingBar
    private lateinit var reviewText: TextInputEditText
    private lateinit var submitButton: MaterialButton

    companion object {
        private const val SUBMIT_REVIEW_URL = "https://yourdomain.com/submit_review.php"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)

        // Initialize views
        ratingBar = findViewById(R.id.rating_bar)
        reviewText = findViewById(R.id.et_review_text)
        submitButton = findViewById(R.id.btn_submit_review)

        // Set submit button click listener
        submitButton.setOnClickListener {
            submitReview()
        }
    }

    private fun submitReview() {
        val rating = ratingBar.rating
        val review = reviewText.text.toString().trim()

        // Validate inputs
        if (rating == 0f) {
            Toast.makeText(this, "Please select a rating", Toast.LENGTH_SHORT).show()
            return
        }

        if (review.isEmpty()) {
            Toast.makeText(this, "Please write a review", Toast.LENGTH_SHORT).show()
            return
        }

        // Prepare request to PHP backend
        val requestQueue = Volley.newRequestQueue(this)
        val stringRequest = object : StringRequest(
            Request.Method.POST, SUBMIT_REVIEW_URL,
            { response ->
                try {
                    val jsonResponse = JSONObject(response)
                    val status = jsonResponse.getString("status")

                    if (status == "success") {
                        Toast.makeText(this, "Review submitted successfully!", Toast.LENGTH_SHORT).show()
                        // Clear form
                        ratingBar.rating = 0f
                        reviewText.text?.clear()
                    } else {
                        val errorMessage = jsonResponse.optString("message", "Unknown error occurred")
                        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Log.e("ReviewSubmission", "Error parsing response", e)
                    Toast.makeText(this, "Error processing response", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Log.e("ReviewSubmission", "Network error", error)
                Toast.makeText(this, "Network error. Please try again.", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["rating"] = rating.toString()
                params["review_text"] = review
                params["user_id"] = "1" // Replace with actual user ID
                return params
            }
        }

        // Add request to queue
        requestQueue.add(stringRequest)
    }
}
package com.example.godrivify.UserScreens

data class UserCarsModule(
    val imageRes:Int,
    val name : String
)

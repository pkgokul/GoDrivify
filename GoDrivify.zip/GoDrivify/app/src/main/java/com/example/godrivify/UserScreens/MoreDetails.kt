package com.example.godrivify.UserScreens

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.example.godrivify.R

class MoreDetails : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_more_details)

        findViewById<ImageButton>(R.id.backButton2).setOnClickListener {
            finish() // Close the activity and return to the previous screen
        }
    }
}

package com.example.godrivify.DriverScreens


import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.godrivify.R
import com.example.godrivify.api.RetrofitClient
import com.example.godrivify.api.ApiService
import com.example.godrivify.response.DriverInfoResponse
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class Adddriverdetails : AppCompatActivity() {

    private lateinit var licenseImageView: ImageView
    private var licenseUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adddriverdetails)

        val ageEditText: EditText = findViewById(R.id.textView16)
        val experienceEditText: EditText = findViewById(R.id.textView17)
        val contactNumberEditText: EditText = findViewById(R.id.textView67)
        val languageEditText: EditText = findViewById(R.id.textViewLanguage)
        val submitButton: Button = findViewById(R.id.submitbutton)
        val uploadButton: Button = findViewById(R.id.uploadButton)
        licenseImageView = findViewById(R.id.licenseImageView)

        uploadButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "image/*"
            startActivityForResult(intent, IMAGE_PICK_CODE)
        }

        submitButton.setOnClickListener {
            val userId = intent.getStringExtra("id") ?: ""
            val age = ageEditText.text.toString().trim().toIntOrNull()
            val experienceYears = experienceEditText.text.toString().trim().toIntOrNull()
            val contactNumber = contactNumberEditText.text.toString().trim()
            val speakingLanguage = languageEditText.text.toString().trim()

            if (userId.isEmpty() || age == null || experienceYears == null || contactNumber.isEmpty() || speakingLanguage.isEmpty() || licenseUri == null) {
                Toast.makeText(
                    this,
                    "Please fill all fields and upload license image",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            addDriverInfo(
                userId,
                age,
                experienceYears,
                contactNumber,
                speakingLanguage,
                licenseUri!!
            )
        }
    }

    //    private fun addDriverInfo(userId: String, age: Int, experienceYears: Int, contactNumber: String, language: String, imageUri: Uri) {
//        val apiService = RetrofitClient.instance.create(ApiService::class.java)
//
//        val file = File(imageUri.path!!)
//        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), file)
//        val licenseImage = MultipartBody.Part.createFormData("license_image", file.name, requestFile)
//
//        val userIdPart = RequestBody.create("text/plain".toMediaTypeOrNull(), userId)
//        val agePart = RequestBody.create("text/plain".toMediaTypeOrNull(), age.toString())
//        val experiencePart = RequestBody.create("text/plain".toMediaTypeOrNull(), experienceYears.toString())
//        val contactPart = RequestBody.create("text/plain".toMediaTypeOrNull(), contactNumber)
//        val languagePart = RequestBody.create("text/plain".toMediaTypeOrNull(), language)
//
//        val call = apiService.addDriverInfo(userIdPart, agePart, experiencePart, contactPart, languagePart, licenseImage)
//        call?.enqueue(object : Callback<DriverInfoResponse?> {
//
//
//            override fun onResponse(
//                call: Call<DriverInfoResponse?>,
//                response: Response<DriverInfoResponse?>
//            ) {
//                if (response.isSuccessful) {
//                    val driverInfoResponse = response.body()
//                    if (driverInfoResponse != null && driverInfoResponse.status) {
//                        Toast.makeText(this@Adddriverdetails, driverInfoResponse.message, Toast.LENGTH_LONG).show()
//                        Log.d("API_RESPONSE", "UserID: ${driverInfoResponse.userid}")
//                        val intent = Intent(this@Adddriverdetails, DriverPage::class.java)
//                        startActivity(intent)
//                        finish()
//                    } else {
//                        Toast.makeText(this@Adddriverdetails, "Failed: ${driverInfoResponse?.message}", Toast.LENGTH_SHORT).show()
//                    }
//                } else {
//                    Toast.makeText(this@Adddriverdetails, "Error: ${response.code()}", Toast.LENGTH_SHORT).show()
//                }
//            }
//
//            override fun onFailure(call: Call<DriverInfoResponse?>, t: Throwable) {
//                Toast.makeText(this@Adddriverdetails, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
//                Log.e("API_ERROR", t.message.orEmpty())
//            }
//        })
//    }
    private fun addDriverInfo(
        userId: String,
        age: Int,
        experienceYears: Int,
        contactNumber: String,
        language: String,
        imageUri: Uri
    ) {
        val apiService = RetrofitClient.instance.create(ApiService::class.java)

        val inputStream = contentResolver.openInputStream(imageUri)
        val tempFile = File.createTempFile("license", ".jpg", cacheDir)
        tempFile.outputStream().use { outputStream ->
            inputStream?.copyTo(outputStream)
        }

        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), tempFile)
        val licenseImage =
            MultipartBody.Part.createFormData("license_image", tempFile.name, requestFile)

        val userIdPart = RequestBody.create("text/plain".toMediaTypeOrNull(), userId)
        val agePart = RequestBody.create("text/plain".toMediaTypeOrNull(), age.toString())
        val experiencePart =
            RequestBody.create("text/plain".toMediaTypeOrNull(), experienceYears.toString())
        val contactPart = RequestBody.create("text/plain".toMediaTypeOrNull(), contactNumber)
        val languagePart = RequestBody.create("text/plain".toMediaTypeOrNull(), language)

        val call = apiService.addDriverInfo(
            userIdPart,
            agePart,
            experiencePart,
            contactPart,
            languagePart,
            licenseImage
        )
        call?.enqueue(object : Callback<DriverInfoResponse?> {
            override fun onResponse(
                call: Call<DriverInfoResponse?>,
                response: Response<DriverInfoResponse?>
            ) {
                if (response.isSuccessful) {
                    val driverInfoResponse = response.body()
                    if (driverInfoResponse != null && driverInfoResponse.status) {
                        Toast.makeText(
                            this@Adddriverdetails,
                            driverInfoResponse.message,
                            Toast.LENGTH_LONG
                        ).show()
                        Log.d("API_RESPONSE", "UserID: ${driverInfoResponse.userid}")
                        val intent = Intent(this@Adddriverdetails, DriverPage::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(
                            this@Adddriverdetails,
                            "Failed: ${driverInfoResponse?.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@Adddriverdetails,
                        "Error: ${response.code()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<DriverInfoResponse?>, t: Throwable) {
                Toast.makeText(this@Adddriverdetails, "Error: ${t.message}", Toast.LENGTH_SHORT)
                    .show()
                Log.e("API_ERROR", t.message.orEmpty())
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == IMAGE_PICK_CODE && resultCode == Activity.RESULT_OK && data != null) {
            licenseUri = data.data
            licenseImageView.setImageURI(licenseUri)
        }
    }

    companion object {
        private const val IMAGE_PICK_CODE = 1001
    }
}

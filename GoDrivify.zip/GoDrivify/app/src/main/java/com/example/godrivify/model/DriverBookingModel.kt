package com.example.godrivify.model

class BookingShowDriver {
    val status: String? = null
    val message: String? = null
}

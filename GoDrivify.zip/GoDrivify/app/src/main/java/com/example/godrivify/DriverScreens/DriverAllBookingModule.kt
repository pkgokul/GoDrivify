package com.example.godrivify.DriverScreens

class DriverAllBookingModule(
    val imageRes:Int,
    val name:String
)

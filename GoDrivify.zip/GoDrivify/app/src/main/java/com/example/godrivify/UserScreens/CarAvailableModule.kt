package com.example.godrivify.UserScreens

data class CarAvailableModule(
    val imageRes:Int,
    val name:String
)
package com.example.godrivify

class ViewAllModule(
    val imageRes:Int,
    val name:String
)
package com.example.godrivify.UserScreens

class DriverAvailableListModule(
        val imageRes:Int,
        val name:String
    )

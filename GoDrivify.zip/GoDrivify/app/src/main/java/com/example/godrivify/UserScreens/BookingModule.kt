package com.example.godrivify.model

data class BookingResponse(
    val booking_id: Int,
    val drivername: String,
    val status: String
)
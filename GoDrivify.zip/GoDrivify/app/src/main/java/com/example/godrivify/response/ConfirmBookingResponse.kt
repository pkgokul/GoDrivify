package com.example.godrivify.response

data class ConfirmBookingResponse(val status:String,val message:String)
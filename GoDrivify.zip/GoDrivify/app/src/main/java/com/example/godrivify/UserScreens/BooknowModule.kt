package com.example.godrivify.UserScreens

class BooknowModule(
    val imageRes:Int,
    val name:String
)
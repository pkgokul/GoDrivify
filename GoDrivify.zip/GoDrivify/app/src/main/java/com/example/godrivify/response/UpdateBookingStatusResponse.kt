data class UpdateBookingStatusResponse(
    val status: Boolean,
    val message: String
)

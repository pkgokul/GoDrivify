package com.example.godrivify.api

import BookingdateResponse
import DetailsResponse
import com.example.godrivify.response.DriverBookingListResponse
import UpdateBookingStatusResponse
import com.example.godrivify.model.BookingShowDriver
import com.example.godrivify.model.CarResponse
import com.example.godrivify.response.DriverInfoResponse
import com.example.godrivify.response.DriverProfileResponse
import com.example.godrivify.response.FetchResponse
import com.example.godrivify.response.GetAvailableDriversResponse
import com.example.godrivify.response.InsertResponse
import com.example.godrivify.response.LoginResponse
import com.example.godrivify.response.PriceResponse
import com.example.godrivify.response.ProfileResponse
import com.example.godrivify.response.SignupResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Query



interface ApiService {

    @FormUrlEncoded
    @POST("GoDrivify/price.php")
    fun calculatePrice(
        @Field("origin") origin: String,
        @Field("destination") destination: String,
        @Field("days") days: Int
    ): Call<PriceResponse>

    @Multipart
    @POST("GoDrivify/signup.php")
    fun signupUser(
        @Part("name") name: RequestBody,
        @Part("username") username: RequestBody,
        @Part("email") email: RequestBody,
        @Part("password") password: RequestBody,
        @Part("role") role: RequestBody,
        @Part("contact_number") contactNumber: RequestBody,
        @Part image: MultipartBody.Part
    ): Call<SignupResponse>



    @FormUrlEncoded
    @POST("GoDrivify/insertavailability.php")
    fun updateAvailability(
        @Field("userid") userId: Int, @Field("availability") availability: String, @Field(
            "availability" + "_date"
        ) availabilityDate: String
    ): Call<InsertResponse>

    @FormUrlEncoded
    @POST("GoDrivify/userlogin.php")
    fun loginUser(
        @Field("username") username: String, @Field("password") password: String
    ): Call<LoginResponse>

    @Multipart
    @POST("GoDrivify/driverinfo.php")
    fun addDriverInfo(
        @Part("userid") userId: RequestBody?,
        @Part("age") age: RequestBody?,
        @Part("experience_years") experienceYears: RequestBody?,
        @Part("contact_number") contactNumber: RequestBody?,
        @Part("speaking_language") speakingLanguage: RequestBody?,
        @Part licenseImage: MultipartBody.Part?
    ): Call<DriverInfoResponse?>?

    @FormUrlEncoded
    @POST("GoDrivify/touchavailability.php")
    fun getAvailableDrivers(@Field("availability_date") availabilityDate: String): Call<GetAvailableDriversResponse>

    @GET("GoDrivify/fetchcars.php")
    fun getCars(): Call<CarResponse>

    @Multipart
    @POST("GoDrivify/cars.php")
    fun uploadCar(
        @Part("userid") userId: RequestBody,
        @Part("car_name") carName: RequestBody,
        @Part("condition") condition: RequestBody,
        @Part image: MultipartBody.Part
    ): Call<InsertResponse>


    @FormUrlEncoded
    @POST("GoDrivify/fetchprofile.php")
    fun getUserProfile(@Field("id") userId: String): Call<ProfileResponse>


    @FormUrlEncoded
    @POST("GoDrivify/insertbookingdetails.php")
    fun insertBookingDetails(
        @Field("userid") userId: String?,
        @Field("driver_id") driverId: Int,
        @Field("dateofbooking") dateOfBooking: String,
        @Field("status") status: String,
        @Field("pickup") pickup: String,
        @Field("drop") drop: String
    ): Call<BookingdateResponse>


    @FormUrlEncoded
    @POST("GoDrivify/fetchdriverprofile.php")
    fun fetchDriverProfile(
        @Field("driver_id") driverId: String
    ): Call<DriverProfileResponse>


    @FormUrlEncoded
    @POST("GoDrivify/fetch_booking_details.php")
    fun fetchBookingDetails(@Field("userid") userId: String): Call<DriverBookingListResponse>


    @FormUrlEncoded
    @POST("GoDrivify/update_booking_status.php")
    fun updateBookingStatus(
        @Field("booking_id") bookingId: Int, @Field("status") status: String
    ): Call<UpdateBookingStatusResponse>

    @FormUrlEncoded
    @POST("GoDrivify/bookindetails.php")
    fun getBookingDetails(
        @Field("userid") userid: String
    ): Call<DetailsResponse>

    @GET("GoDrivify/viewallfetch.php")
    fun getAvailableDrivers(): Call<FetchResponse>



    @Multipart
    @POST("GoDrivify/insertbookingdetails.php")
    fun insertBooking(
        @Part("userid") userid: RequestBody?,
        @Part("driver_id") driver_id: RequestBody?,
        @Part("dateofbooking") dateofbooking: RequestBody?,
        @Part("status") status: RequestBody?,
        @Part("pickup") pickup: RequestBody?,
        @Part("drop") drop_location: RequestBody?,
        @Part("car_name") car_name: RequestBody?,
        @Part car_image: MultipartBody.Part?
    ): Call<BookingShowDriver?>?


}












package com.example.godrivify.UserScreens

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.example.godrivify.Auth.CommonLoginActivity
import com.example.godrivify.R
import com.example.godrivify.api.ApiService
import com.example.godrivify.api.RetrofitClient
import com.example.godrivify.api.RetrofitClient.BASE_URL_IMAGE
import com.example.godrivify.response.ProfileResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Profilepage : AppCompatActivity() {

    private lateinit var tvName: TextView
    private lateinit var tvUsername: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvContactNumber: TextView
    private lateinit var tvPassword: TextView
    private lateinit var ivProfileImage: ImageView
    private lateinit var logoutButton: Button
    private lateinit var backButton: ImageButton
    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profilepage)

        // Initialize UI components
        tvName = findViewById(R.id.usern)
        tvUsername = findViewById(R.id.textView9)
        tvEmail = findViewById(R.id.email)
        tvContactNumber = findViewById(R.id.contactNumber)
        tvPassword = findViewById(R.id.password)
        ivProfileImage = findViewById(R.id.imageProfile)
        logoutButton = findViewById(R.id.logoutbutton)
        backButton = findViewById(R.id.backButton3)

        // Retrieve user ID from SharedPreferences
        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        val userId = sharedPreferences.getString("id", null)

        // Fetch and display user profile if ID is available
        if (userId != null) {
            fetchUserProfile(userId)
        } else {
            Toast.makeText(this, "User ID not found!", Toast.LENGTH_SHORT).show()
        }

        // Handle logout button click
        logoutButton.setOnClickListener {
            val editor = sharedPreferences.edit()
            editor.clear() // Clear saved user data
            editor.apply()

            val intent = Intent(this, CommonLoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Handle back button click
        backButton.setOnClickListener {
            finish()
        }

        // Apply window insets for proper layout adjustment
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(
                view.paddingLeft,
                view.paddingTop + systemBarsInsets.top,
                view.paddingRight,
                view.paddingBottom + systemBarsInsets.bottom
            )
            insets
        }
    }

    private fun fetchUserProfile(userId: String) {
        val apiService = RetrofitClient.instance.create(ApiService::class.java)
        apiService.getUserProfile(userId).enqueue(object : Callback<ProfileResponse> {
            override fun onResponse(call: Call<ProfileResponse>, response: Response<ProfileResponse>) {
                if (response.isSuccessful && response.body()?.status == true) {
                    val userData = response.body()?.data
                    if (userData != null) {
                        tvName.text = userData.name
                        tvUsername.text = userData.username
                        tvEmail.text = userData.email
                        tvContactNumber.text = userData.contact_number
                        tvPassword.text = "********" // Hide actual password for security

                        // Load profile image using Glide
                        val imageUrl = BASE_URL_IMAGE + userData.image_path
                        Glide.with(this@Profilepage)
                            .load(imageUrl)
                            .placeholder(R.drawable.pi)
                            .error(R.drawable.drop_down_ic)
                            .into(ivProfileImage)
                    }
                } else {
                    Toast.makeText(this@Profilepage, "User not found", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ProfileResponse>, t: Throwable) {
                Toast.makeText(this@Profilepage, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

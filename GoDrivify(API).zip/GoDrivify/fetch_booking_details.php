<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include "db.php"; // Ensure database connection

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "GET") {  // Changed POST to GET
    if (isset($_GET['userId'])) {  // Changed $_POST to $_GET and matched param name
        $userId = intval($_GET['userId']);

        // Fetch only pending bookings and join with signup table to get username
        $stmt = $conn->prepare("
            SELECT b.id, b.userid, s.username, b.dateofbooking, b.status 
            FROM bookingdetails b 
            INNER JOIN signup s ON b.userid = s.id 
            WHERE b.driver_id = ? AND b.status = 'pending'
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $bookings = array();
            while ($row = $result->fetch_assoc()) {
                $bookings[] = $row;
            }
            $response['status'] = true;
            $response['message'] = "Pending bookings fetched successfully";
            $response['data'] = $bookings;
        } else {
            $response['status'] = false;
            $response['message'] = "No pending bookings found for this driver";
        }

        $stmt->close();
    } else {
        $response['status'] = false;
        $response['message'] = "Driver ID is required";
    }
} else {
    $response['status'] = false;
    $response['message'] = "Invalid request method";
}

echo json_encode($response);
$conn->close();
?>

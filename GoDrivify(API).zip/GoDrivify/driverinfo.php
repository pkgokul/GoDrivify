<?php
// Include database connection file
include_once 'db.php';

// Set response type to JSON
header('Content-Type: application/json');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get input values from the form
    $userid = isset($_POST['userid']) ? htmlspecialchars(strip_tags($_POST['userid'])) : '';
    $age = isset($_POST['age']) ? htmlspecialchars(strip_tags($_POST['age'])) : '';
    $experience_years = isset($_POST['experience_years']) ? htmlspecialchars(strip_tags($_POST['experience_years'])) : '';
    $contact_number = isset($_POST['contact_number']) ? htmlspecialchars(strip_tags($_POST['contact_number'])) : '';
    $speaking_language = isset($_POST['speaking_language']) ? htmlspecialchars(strip_tags($_POST['speaking_language'])) : '';

    // Validate required fields
    if (empty($userid) || empty($age) || empty($experience_years) || empty($contact_number) || empty($speaking_language)) {
        echo json_encode(['status' => false, 'message' => 'All fields are required.']);
        exit();
    }

    // Handle license image upload
    if (isset($_FILES['license_image']) && $_FILES['license_image']['error'] == 0) {
        $file_tmp = $_FILES['license_image']['tmp_name'];
        $file_size = $_FILES['license_image']['size'];

        // Check if the file is an actual image
        $image_info = getimagesize($file_tmp);
        if ($image_info === false) {
            echo json_encode(['status' => false, 'message' => 'Invalid file. Please upload a valid image.']);
            exit();
        }

        // Increase file size limit to 5MB
        if ($file_size > 5 * 1024 * 1024) {
            echo json_encode(['status' => false, 'message' => 'File size must be less than 5MB.']);
            exit();
        }

        // Set upload directory and move the file
        $upload_dir = 'uploads/licenses/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = time() . '_' . basename($_FILES['license_image']['name']);
        $file_path = $upload_dir . $file_name;

        if (move_uploaded_file($file_tmp, $file_path)) {
            $license_image_url = $file_path;
        } else {
            echo json_encode(['status' => false, 'message' => 'Error uploading the license image.']);
            exit();
        }
    } else {
        echo json_encode(['status' => false, 'message' => 'License image is required.']);
        exit();
    }

    // Insert data into the database
    $query = "INSERT INTO driverinfo (userid, age, experienceyears, contactnumber, language, lic_image) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiisss", $userid, $age, $experience_years, $contact_number, $speaking_language, $license_image_url);

    if ($stmt->execute()) {
        echo json_encode([
            'status' => true,
            'message' => 'Driver details added successfully!',
            'userid' => $userid
        ]);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Error: ' . $stmt->error
        ]);
    }

    // Close the statement
    $stmt->close();
} else {
    echo json_encode(['status' => false, 'message' => 'Invalid request method.']);
}

// Close the database connection
$conn->close();
?>

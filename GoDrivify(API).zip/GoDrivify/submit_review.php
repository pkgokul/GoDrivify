<?php
// File: submit_review.php
include'db.php';
header('Content-Type: application/json');

// Database Configuration
$host = 'localhost';
$dbname = 'reviews_database';
$username = 'your_database_username';
$password = 'your_database_password';

// Database Connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database Connection Failed'
    ]);
    exit;
}

// Input Validation
function validateInput($rating, $review) {
    $errors = [];

    // Validate rating
    if (!is_numeric($rating) || $rating < 1 || $rating > 5) {
        $errors[] = 'Invalid rating';
    }

    // Validate review text
    $review = trim($review);
    if (empty($review)) {
        $errors[] = 'Review cannot be empty';
    }
    if (strlen($review) > 500) {
        $errors[] = 'Review too long (max 500 characters)';
    }

    return $errors;
}

// Handle POST Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = $_POST['rating'] ?? null;
    $review_text = $_POST['review_text'] ?? '';
    $user_id = $_POST['user_id'] ?? null;

    // Validate inputs
    $validation_errors = validateInput($rating, $review_text);
    if (!empty($validation_errors)) {
        echo json_encode([
            'status' => 'error',
            'errors' => $validation_errors
        ]);
        exit;
    }

    // Prepare SQL Statement
    try {
        $stmt = $pdo->prepare("
            INSERT INTO reviews 
            (user_id, rating, review_text, created_at) 
            VALUES (:user_id, :rating, :review_text, NOW())
        ");
        
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':rating', $rating, PDO::PARAM_INT);
        $stmt->bindParam(':review_text', $review_text, PDO::PARAM_STR);

        $stmt->execute();

        // Return success response
        echo json_encode([
            'status' => 'success',
            'message' => 'Review submitted successfully',
            'review_id' => $pdo->lastInsertId()
        ]);
    } catch(PDOException $e) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Submission failed'
        ]);
    }
} else {
    // Invalid request method
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method Not Allowed'
    ]);
}
?>